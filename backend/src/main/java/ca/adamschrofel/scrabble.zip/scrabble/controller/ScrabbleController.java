package ca.adamschrofel.scrabble.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ca.adamschrofel.scrabble.InputValidator;
import ca.adamschrofel.scrabble.board.Board;
import ca.adamschrofel.scrabble.dto.BestPlay;
import ca.adamschrofel.scrabble.dto.BoardSolveRequest;
import ca.adamschrofel.scrabble.dto.BoardState;
import ca.adamschrofel.scrabble.dto.BoardTileUpdate;
import ca.adamschrofel.scrabble.dto.BoardUpdateRequest;
import ca.adamschrofel.scrabble.dto.DefinitionResponse;
import ca.adamschrofel.scrabble.dto.ScoreWord;
import ca.adamschrofel.scrabble.dto.SolveResponse;
import ca.adamschrofel.scrabble.dto.WordGroup;
import ca.adamschrofel.scrabble.exceptions.InvalidTilesException;
import ca.adamschrofel.scrabble.rack.LengthGroup;
import ca.adamschrofel.scrabble.scoring.ScrabbleScoring;
import ca.adamschrofel.scrabble.service.BoardService;
import ca.adamschrofel.scrabble.service.DefinitionService;
import ca.adamschrofel.scrabble.service.ScrabbleService;




/**
 * REST controller that handles HTTP requests for word solving and word.
 * definitions.
 * Exposes two endpoints: /api/solve for finding valid Scrabble words from
 * tiles,
 * and /api/define for retrieving word definitions from the CSW dictionary.
 */
@RestController
@RequestMapping("/api")
public class ScrabbleController {
    private final ScrabbleService service;
    private final DefinitionService definitions;
    private final BoardService board;

    /**
     * Constructor that injects dependencies via Spring autowiring.
     * ScrabbleService handles word finding logic and DefinitionService
     * provides word definitions.
     *
     * @param service     The service for solving Scrabble words from a tile rack
     * @param definitions The service for retrieving word definitions
     */
    public ScrabbleController(ScrabbleService service, DefinitionService definitions, BoardService board) {
        this.service = service;
        this.definitions = definitions;
        this.board = board;
    }

    /**
     * Finds all valid Scrabble words that can be formed from a given set of tiles.
     * Accepts tile input including blank tiles (? or *) and returns results grouped
     * by word length.
     *
     * @param tiles A string of tile characters (A-Z, ?, or *) representing the
     *              player's rack
     * @return A map containing the normalized tiles and groups of words organized
     *         by length
     * @throws InvalidTilesException If the input contains invalid characters or
     *                               exceeds 15 tiles
     */
    /**
     * Rack-only solver.
     *
     * <p>Primary route: {@code GET /api/rack/solve?tiles=...}
     * (Alias: {@code GET /api/solve?tiles=...})</p>
     */
    @GetMapping({"/rack/solve", "/solve"})
    public SolveResponse solveRack(@RequestParam String tiles) throws InvalidTilesException {
        // Validate and normalize the tile input (uppercase, no spaces, check for valid
        // chars)
        String tilesNormalized = InputValidator.normalizeTiles(tiles);

        List<WordGroup> groups = new ArrayList<>();

        for (LengthGroup g : service.solve(tilesNormalized)) {
            List<ScoreWord> scored = new ArrayList<>();
            for (String w : g.words()) {
                scored.add(new ScoreWord(w, ScrabbleScoring.scoreWord(w)));
            }
            groups.add(new WordGroup(g.length(), scored));
        }
        return new SolveResponse(tilesNormalized, groups);

    }

    /**
     * Retrieves the definition of a given word from the CSW dictionary.
     * Returns whether the word was found and its definition if available.
     *
     * @param word The word
     * @return A map containing the word, whether it was found, and its definition
     *         (or null if not found)
     */
    /**
     * Dictionary definition lookup.
     *
     * <p>Primary route: {@code GET /api/word/define?word=...}
     * (Alias: {@code GET /api/define?word=...})</p>
     */
    @GetMapping({"/word/define", "/define"})
    public DefinitionResponse define(@RequestParam String word) {
        // Look up the word in the definitions dictionary

        String normalized = word == null ? null : word.trim().toUpperCase();
        String definition = (normalized == null) ? null : definitions.getDefinition(normalized);
        return new DefinitionResponse(normalized, definition != null, definition);
    }

    /**
     * Board solver (best plays) using the current server-side board state.
     *
     * <p>Primary route: {@code POST /api/board/solve} with JSON body.
     * (Alias: {@code GET /api/bestplays?tiles=...&limit=...})</p>
     */
    @PostMapping("/board/solve")
    public List<BestPlay> solveBoard(@RequestBody BoardSolveRequest request) throws InvalidTilesException {
        String rack = request == null ? null : request.rack();
        int limit = (request != null && request.limit() != null) ? request.limit() : 25;

        Board current = board.snapshotBoard();
        return service.bestPlays(current, rack, limit);
    }

    /**
     * Backward-compatible alias for board solving.
     */
    @GetMapping("/bestplays")
    public List<BestPlay> bestPlaysAlias(
            @RequestParam String tiles,
            @RequestParam(defaultValue = "25") int limit) throws InvalidTilesException {
        Board current = board.snapshotBoard();
        return service.bestPlays(current, tiles, limit);
    }

    @GetMapping("/board")
    public BoardState getBoard() {
        return new BoardState(BoardService.SIZE, board.rowsAsStrings());
    }

    @PostMapping("/board/reset")
    public BoardState resetBoard() {
        board.reset();
        return new BoardState(BoardService.SIZE, board.rowsAsStrings());
    }

    @PostMapping("/board/tile")
    public BoardState setTile(@RequestBody BoardTileUpdate req) {
        char tile = normalizeTile(req == null ? null : req.tile());
        board.set(req.row(), req.column(), tile);
        return new BoardState(BoardService.SIZE, board.rowsAsStrings());
    }

    @PostMapping("/board/tiles")
    public BoardState setTiles(@RequestBody BoardUpdateRequest req) {
        if (req != null && req.tiles() != null) {
            for (BoardTileUpdate t : req.tiles()) {
                char tile = normalizeTile(t.tile());
                board.set(t.row(), t.column(), tile);
            }
        }
        return new BoardState(BoardService.SIZE, board.rowsAsStrings());
    }

    private char normalizeTile(String tile) {
        if (tile == null)
            return '.';
        String s = tile.trim();
        if (s.isEmpty() || s.equals("."))
            return '.';
        char ch = Character.toUpperCase(s.charAt(0));
        return ch;
    }

}
