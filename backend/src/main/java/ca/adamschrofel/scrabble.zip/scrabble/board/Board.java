package ca.adamschrofel.scrabble.board;

import java.util.ArrayList;
import java.util.List;

import ca.adamschrofel.scrabble.dto.PlacedTile;
import ca.adamschrofel.scrabble.dto.Placement;

/**
 * TODO(#1) finish commenting file
 */
public class Board {
    public static final int SIZE = 15;
    private final char[][] grid = new char[SIZE][SIZE];

    public Board() {
        // initialize board with empty tiles
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                grid[i][j] = '.';
            }
        }
    }

    public char getTile(int row, int column) {
        checkBoundary(row, column);
        return grid[row][column];
    }

    public void setTile(int row, int column, char tile) {
        checkBoundary(row, column);
        grid[row][column] = Character.toUpperCase(tile);

    }

    private void checkBoundary(int row, int column) {
        if (row < 0 || row >= SIZE || column < 0 || column >= SIZE) {
            throw new IllegalArgumentException("Out of bounds " + row + ", " + column);
        }
    }

    // Placement stuff
    public boolean canPlace(Placement p) {
        String w = p.word().toUpperCase();
        // converts direction into tile placement
        // compute board coordinates
        int dr = p.direction().directionRow;
        int dc = p.direction().directionColumn;

        for (int i = 0; i < w.length(); i++) {
            int x = p.row() + dr * i;
            int y = p.column() + dc * i;

            // check if it fits on board
            if (x < 0 || x >= SIZE || y < 0 || y >= SIZE) {
                return false;
            }
            char placedTile = Character.toUpperCase(w.charAt(i));
            char existingTile = grid[x][y];
            // if theres nothing there we can place
            if (existingTile != '.' && existingTile != placedTile)
                return false;
        }
        return true;

    }

    public List<PlacedTile> place(Placement p) {
        if (!canPlace(p)) {
            throw new IllegalArgumentException("Illegal Placement");
        }

        String word = p.word().toUpperCase();

        int dr = p.direction().directionRow;
        int dc = p.direction().directionColumn;

        List<PlacedTile> newlyPlaced = new ArrayList<>();

        for (int i = 0; i < word.length(); i++) {
            int x = p.row() + dr * i;
            int y = p.column() + dc * i;

            char placedTile = Character.toUpperCase(word.charAt(i));
            char existingTile = grid[x][y];

            if (existingTile == '.') {
                grid[x][y] = placedTile;
                newlyPlaced.add(new PlacedTile(x, y, placedTile, false));
            }
        }
        return newlyPlaced;

    }

    // TODO: track occupied tile count so it doesnt scan for emptiness
    // checks if tile is empty
    public boolean isEmpty() {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                if (grid[i][j] != '.') {
                    return false;
                }
            }
        }
        return true;
    }

    // checks if tile is being placed on the centre
    // which would signify double word score and start of game
    public boolean coversCenter(Placement p) {
        final int center = 7;
        String word = p.word().toUpperCase();

        int dr = p.direction().directionRow;
        int dc = p.direction().directionColumn;

        for (int i = 0; i < word.length(); i++) {
            int x = p.row() + dr * i;
            int y = p.column() + dc * i;
            if (x == center && y == center) {
                return true;
            }
        }
        return false;

    }

    public boolean touchesExistingTile(Placement p) {
        String word = p.word().toUpperCase();

        int dr = p.direction().directionRow;
        int dc = p.direction().directionColumn;

        for (int i = 0; i < word.length(); i++) {
            int row = p.row() + dr * i;
            int column = p.column() + dc * i;

            if (grid[row][column] != '.') {
                return true;
            }

            if (hasTileAt(row - 1, column) || hasTileAt(row + 1, column)
                    || hasTileAt(row, column - 1) || hasTileAt(row, column + 1)) {
                return true;
            }
        }
        return false;
    }

    private boolean hasTileAt(int row, int column) {
        if (row < 0 || row >= SIZE || column < 0 || column >= SIZE) {
            return false;
        }
        return grid[row][column] != '.';
    }

    public boolean isLegalPlacement(Placement p) {
        if (!canPlace(p)) {
            return false;
        }

        if (isEmpty()) {
            return coversCenter(p);
        } else {
            return touchesExistingTile(p);
        }
    }

    /**
     * Undo a prior applyTiles call
     */
    public void unapplyTiles(List<PlacedTile> newlyPlacedTiles) {
        for (PlacedTile t : newlyPlacedTiles) {
            grid[t.row()][t.column()] = '.';
        }
    }

    /**
     * Apply a list of tiles onto the board (used by solver evaluation)
     * Tiles are assumed to only target empty squares
     */
    public void applyTiles(List<PlacedTile> tiles) {
        for (PlacedTile t : tiles) {
            setTile(t.row(), t.column(), t.tile());
        }
    }

}
